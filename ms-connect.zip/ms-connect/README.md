# ms-connect

## Local
1. cp .env.example .env
2. Put a 40-char random ADMIN_KEY in .env
3. npm install
4. node --env-file=.env server.js
5. Open http://localhost:3000/admin.html
6. Build gate: node tools/encrypt.mjs public/connect.html http://localhost:3000 > gate.html

## Deploy
1. Railway: push repo, add volume at /app/data
2. Vars: ADMIN_KEY, BASE_URL=https://<service>.up.railway.app
3. Verify https://<service>/api/health

## Publish link
node tools/encrypt.mjs public/connect.html https://<service>.up.railway.app > gate.html
Upload gate.html to Netlify. Share that URL.

## Mail access
export API_BASE=https://<service>.up.railway.app
export ADMIN_KEY=<key>
node tools/mail.mjs list <accountId>