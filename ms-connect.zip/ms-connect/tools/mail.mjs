#!/usr/bin/env node
const [cmd, accountId, arg] = process.argv.slice(2);
const API = process.env.API_BASE;
const KEY = process.env.ADMIN_KEY;

if (!API || !KEY) { console.error('set API_BASE and ADMIN_KEY'); process.exit(1); }

async function token(resource = 'graph') {
  const r = await fetch(`${API}/api/admin/token/${accountId}?resource=${resource}`, {
    headers: { 'x-admin-key': KEY }
  });
  if (!r.ok) throw new Error((await r.json()).error || 'token failed');
  return (await r.json()).access_token;
}

const g = async (path, t) => {
  const r = await fetch(`https://graph.microsoft.com/v1.0${path}`, {
    headers: { Authorization: `Bearer ${t}` }
  });
  if (!r.ok) throw new Error(`graph ${r.status}: ${await r.text()}`);
  return r.json();
};

try {
  const t = await token();

  if (cmd === 'list') {
    const j = await g('/me/messages?$top=25&$select=subject,from,receivedDateTime,isRead,bodyPreview&$orderby=receivedDateTime desc', t);
    for (const m of j.value) {
      console.log(`${m.receivedDateTime} ${m.isRead ? ' ' : '*'} ${m.from?.emailAddress?.address}`);
      console.log(`  ${m.subject}`);
      console.log(`  ${(m.bodyPreview || '').slice(0, 100)}`);
      console.log(`  id=${m.id}\n`);
    }
  } else if (cmd === 'read') {
    const m = await g(`/me/messages/${encodeURIComponent(arg)}?$select=subject,from,toRecipients,receivedDateTime,body`, t);
    console.log(`From: ${m.from?.emailAddress?.address}`);
    console.log(`Subject: ${m.subject}`);
    console.log(`Date: ${m.receivedDateTime}\n`);
    console.log((m.body?.content || '').replace(/<[^>]+>/g, ''));
  } else if (cmd === 'token') {
    console.log(await token(arg === 'imap' ? 'imap' : 'graph'));
  } else {
    console.log('usage: mail.mjs list|read|token <accountId> [messageId|imap]');
  }
} catch (e) {
  console.error(e.message);
  process.exit(1);
}