#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

need=(package.json server.js public/connect.html public/admin.html tools/encrypt.mjs tools/gate.template.html tools/mail.mjs)
for f in "${need[@]}"; do
  [ -f "$f" ] || { echo "MISSING FILE: $f"; exit 1; }
done

command -v node >/dev/null || { echo "node is not installed"; exit 1; }
MAJOR=$(node -p 'process.versions.node.split(".")[0]')
[ "$MAJOR" -ge 18 ] || { echo "need node 18+, found $(node -v)"; exit 1; }

if [ ! -f .env ]; then
  KEY=$(node -e 'console.log(require("crypto").randomBytes(20).toString("hex"))')
  printf 'ADMIN_KEY=%s\nBASE_URL=http://localhost:3000\n' "$KEY" > .env
  echo "created .env with a fresh ADMIN_KEY"
else
  echo ".env already present, leaving it alone"
fi

npm install --silent
echo "dependencies installed"

node tools/encrypt.mjs public/connect.html http://localhost:3000 > gate.html
cp gate.html public/gate.local.html
echo "gate built and staged for preview"

if node --env-file=.env -e '' 2>/dev/null; then
  node --env-file=.env server.js & echo $! > .server.pid
else
  echo "(node too old for --env-file, exporting manually)"
  set -a; . ./.env; set +a
  node server.js & echo $! > .server.pid
fi

for i in $(seq 1 20); do
  sleep 0.5
  if curl -fsS http://localhost:3000/api/health >/dev/null 2>&1; then
    echo "server is up"
    break
  fi
  if [ "$i" -eq 20 ]; then echo "server never answered on :3000"; exit 1; fi
done

cat <<EOF

Ready.
  panel : http://localhost:3000/admin.html
  gate  : http://localhost:3000/gate.local.html
  stop  : kill \$(cat .server.pid)

ADMIN_KEY is in .env — open the panel and paste it.
EOF